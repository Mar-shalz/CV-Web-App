// Filled in by `npm run extension:build` (EXT_APP_URL, or the live address by default).
export const APP_URL = "https://cv-web-app-victor-ajibodu-s-projects.vercel.app";
