// Filled in by `npm run extension:build` (EXT_APP_URL, or the live address by default).
export const APP_URL = "https://applywithproof.vercel.app";
